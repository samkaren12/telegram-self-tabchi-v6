import React, { useState, useEffect } from "react";
import {
  Server,
  Activity,
  Cpu,
  Shield,
  Key,
  Globe,
  Radio,
  Clock,
  Terminal,
  Layers,
  Bot,
  Save,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Bookmark,
  Sparkles,
  ExternalLink,
  Zap,
  Power,
  RefreshCw,
  Send,
  Sliders,
  Check,
  Download,
  Lightbulb,
} from "lucide-react";
import { Language, translations } from "../utils/i18n";
import { Volume2, VolumeX, BellRing } from "lucide-react";
import { SystemHealth } from "../types";
import { UpdateManager } from "./UpdateManager";
import { SslBackgroundServiceManager } from "./SslBackgroundServiceManager";
import { AutoBackupManager } from "./AutoBackupManager";
import { SessionHealthScoreCard } from "./SessionHealthScoreCard";

interface SystemStatusProps {
  health: SystemHealth | null;
  lang: Language;
  onOpenOwnerPasswordModal?: () => void;
  soundEnabled?: boolean;
  onToggleSound?: () => void;
  onTestSound?: () => void;
  volume?: number;
  onVolumeChange?: (v: number) => void;
  onOpenHelp?: (section?: any) => void;
}

export const SystemStatus: React.FC<SystemStatusProps> = ({
  health,
  lang,
  onOpenOwnerPasswordModal,
  soundEnabled = true,
  onToggleSound,
  onTestSound,
  volume = 0.45,
  onVolumeChange,
  onOpenHelp,
}) => {
  const t = translations[lang];

  // BotFather Controller & MTProto API State
  const [botEnabled, setBotEnabled] = useState(false);
  const [botToken, setBotToken] = useState("");
  const [ownerId, setOwnerId] = useState("");
  const [botUsername, setBotUsername] = useState("");
  const [botFirstName, setBotFirstName] = useState("");
  const [botStatus, setBotStatus] = useState<"connected" | "disconnected" | "error">("disconnected");
  const [apiId, setApiId] = useState("");
  const [apiHash, setApiHash] = useState("");
  const [buttonLayout, setButtonLayout] = useState<"3-cols" | "2-cols" | "1-col">("3-cols");
  const [savingBot, setSavingBot] = useState(false);
  const [testingBot, setTestingBot] = useState(false);
  const [botFeedback, setBotFeedback] = useState<string | null>(null);
  const [isFeedbackError, setIsFeedbackError] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  useEffect(() => {
    fetchBotSettings();
  }, []);

  const fetchBotSettings = async () => {
    try {
      const res = await fetch("/api/bot-settings");
      const data = await res.json();
      const b = data.settings || data.bot;
      if (b) {
        setBotEnabled(Boolean(b.enabled));
        setBotToken(b.bot_token || "");
        setOwnerId(b.owner_id ? String(b.owner_id) : "");
        setBotUsername(b.bot_username || "");
        setBotFirstName(b.bot_first_name || "");
        setBotStatus(b.status || (b.enabled && b.bot_token ? "connected" : "disconnected"));
        if (b.button_layout) setButtonLayout(b.button_layout);
        if (b.api_id) setApiId(String(b.api_id));
        if (b.api_hash) setApiHash(String(b.api_hash));
      }
    } catch (_) {}
  };

  const handleTestAndConnect = async () => {
    if (!botToken.trim()) {
      setIsFeedbackError(true);
      setBotFeedback(lang === "fa" ? "لطفاً ابتدا توکن ربات تلگرام را وارد کنید." : "Please enter the bot token first.");
      return;
    }

    setTestingBot(true);
    setBotFeedback(null);
    setIsFeedbackError(false);

    try {
      // 1. Live test token via API
      const testRes = await fetch("/api/bot/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ botToken: botToken.trim() }),
      });
      const testData = await testRes.json();
      if (!testRes.ok || !testData.success) {
        throw new Error(testData.message || (lang === "fa" ? "توکن واردشده معتبر نیست یا دسترسی تلگرام مسدود است." : "Invalid bot token."));
      }

      // 2. Save settings and activate bot
      const saveRes = await fetch("/api/bot-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enabled: true,
          botToken: botToken.trim(),
          ownerId: ownerId.trim(),
          apiId: apiId ? Number(apiId) : undefined,
          apiHash: apiHash ? apiHash.trim() : undefined,
        }),
      });
      const saveData = await saveRes.json();
      if (!saveRes.ok || !saveData.success) {
        throw new Error(saveData.message || "Failed to save bot settings.");
      }

      setBotEnabled(true);
      setBotUsername(testData.username || "");
      setBotFirstName(testData.firstName || "Bot");
      setBotStatus("connected");

      setBotFeedback(
        lang === "fa"
          ? `ربات با موفقیت تایید و متصل شد: @${testData.username} (${testData.firstName}). اکنون دکمه‌های شیشه‌ای در تلگرام فعال هستند!`
          : `Bot verified & connected: @${testData.username}. Telegram inline glass keys are now active!`
      );
    } catch (err: any) {
      setIsFeedbackError(true);
      setBotStatus("error");
      setBotFeedback(err.message || (lang === "fa" ? "خطا در اتصال به ربات تلگرام" : "Bot connection error"));
    } finally {
      setTestingBot(false);
    }
  };

  const handleDisconnectBot = async () => {
    setSavingBot(true);
    try {
      await fetch("/api/bot-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enabled: false,
          botToken: botToken.trim(),
          ownerId: ownerId.trim(),
          apiId: apiId ? Number(apiId) : undefined,
          apiHash: apiHash ? apiHash.trim() : undefined,
        }),
      });
      setBotEnabled(false);
      setBotStatus("disconnected");
      setBotFeedback(lang === "fa" ? "ارتباط ربات تلگرام متوقف شد." : "Bot controller disconnected.");
      setTimeout(() => setBotFeedback(null), 4000);
    } catch (_) {
    } finally {
      setSavingBot(false);
    }
  };

  const handleSaveBotSettings = async () => {
    setSavingBot(true);
    setBotFeedback(null);
    setIsFeedbackError(false);
    try {
      const res = await fetch("/api/bot-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enabled: botEnabled,
          botToken: botToken.trim(),
          ownerId: ownerId.trim(),
          buttonLayout,
          apiId: apiId ? Number(apiId) : undefined,
          apiHash: apiHash ? apiHash.trim() : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || "Failed to save bot settings.");
      }
      const b = data.settings || data.bot;
      if (b?.bot_username) {
        setBotUsername(b.bot_username);
      }
      if (b?.bot_first_name) {
        setBotFirstName(b.bot_first_name);
      }
      setBotStatus(b.enabled ? "connected" : "disconnected");
      setBotFeedback(
        lang === "fa"
          ? `تنظیمات ذخیره شد ${b?.bot_username ? `(متصل به @${b.bot_username})` : ""}`
          : `Settings saved successfully ${b?.bot_username ? `(@${b.bot_username})` : ""}`
      );
      setTimeout(() => setBotFeedback(null), 5000);
    } catch (err: any) {
      setIsFeedbackError(true);
      setBotStatus("error");
      setBotFeedback(err.message || "Error saving bot config");
    } finally {
      setSavingBot(false);
    }
  };

  const formatUptime = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    return `${m}m ${s}s`;
  };

  return (
    <div className="space-y-6" dir={lang === "fa" ? "rtl" : "ltr"}>
      {/* Top Banner with Quick Visual Guide Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-black/60 border border-emerald-500/30 rounded-2xl shadow-[0_0_20px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Server className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="font-bold text-slate-100 text-sm sm:text-base">
              {lang === "fa" ? "وضعیت هسته سرور، دیمن ۲۴/۷ و خط فرمان" : "Server Core & 24/7 Daemon Health"}
            </h3>
            <p className="text-xs text-slate-400">
              {lang === "fa" ? "پایش حافظه، وضعیت سشن‌های MTProto، مدیریت دامنه و SSL" : "Monitor resources, sessions, domains and SSL certificates"}
            </p>
          </div>
        </div>

        {onOpenHelp && (
          <button
            type="button"
            onClick={() => onOpenHelp("system")}
            className="self-end sm:self-auto flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 font-bold text-xs shadow-[0_0_15px_rgba(16,185,129,0.2)] transition-all active:scale-95 cursor-pointer whitespace-nowrap"
            title="آموزش دستورات لینوکس و کار با سرور"
          >
            <Lightbulb className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>راهنمای سرور و ترمینال 💡</span>
          </button>
        )}
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Status */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg">
          <div className="flex items-center justify-between gap-3 mb-3">
            <span className="text-xs font-medium text-slate-400">
              {t.system.gateway}
            </span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <div className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-400" />
            <span>{t.system.gatewayStatus}</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1 font-mono">
            DC IP Protocol: MTProto v2.0
          </p>
        </div>

        {/* Uptime */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg">
          <div className="flex items-center justify-between gap-3 mb-3">
            <span className="text-xs font-medium text-slate-400">
              {t.system.uptime}
            </span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-lg font-bold font-mono text-cyan-300">
            {health ? formatUptime(health.uptimeSeconds) : "..."}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            24/7 Permanent Background Loop
          </p>
        </div>

        {/* RAM Usage */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg">
          <div className="flex items-center justify-between gap-3 mb-3">
            <span className="text-xs font-medium text-slate-400">
              {t.system.memory}
            </span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-lg font-bold font-mono text-purple-300">
            {health ? `${health.memoryUsageMb} MB` : "..."}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Node.js V8 Heap & Native Buffer
          </p>
        </div>

        {/* Active Accounts */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg">
          <div className="flex items-center justify-between gap-3 mb-3">
            <span className="text-xs font-medium text-slate-400">
              {t.system.activeAccounts}
            </span>
            <Layers className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-lg font-bold font-mono text-amber-300">
            {health ? `${health.connectedAccountsCount} Accounts` : "..."}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Telethon / GramJS Multi-Client
          </p>
        </div>
      </div>

      {/* Real-time Session Health Score (0-100%) Card */}
      <SessionHealthScoreCard lang={lang} />

      {/* BotFather Remote Controller Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-800/80">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 flex-shrink-0 shadow-lg shadow-cyan-950/40">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h4 className="font-bold text-slate-100 text-sm sm:text-base">
                  {t.system.botTitle}
                </h4>
                {botStatus === "connected" && botUsername ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-bold border border-emerald-500/30 flex items-center gap-1.5 shadow-sm">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    {lang === "fa" ? "آنلاین و متصل" : "Connected"}
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[11px] font-medium border border-slate-700 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-slate-500"></span>
                    {lang === "fa" ? "غیرفعال" : "Disconnected"}
                  </span>
                )}
                {botUsername && (
                  <a
                    href={`https://t.me/${botUsername}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 text-[11px] font-mono font-bold border border-cyan-500/30 flex items-center gap-1 hover:bg-cyan-500/25 transition-all"
                  >
                    <span>@{botUsername}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
              <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
                {lang === "fa"
                  ? "با اتصال ربات، می‌توانید بدون نیاز به ورود به این پنل، از طریق کلیدهای شیشه‌ای لمسی و رنگی در تلگرام، سلف تایم، تبچی و اکانت‌های خود را کنترل کنید."
                  : "Connect your Telegram bot to manage Self-Time, Tabchi, and accounts remotely using native inline glass keyboards."}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-start">
            {botUsername && botStatus === "connected" && (
              <a
                href={`https://t.me/${botUsername}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-bold transition-all shadow-sm"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{lang === "fa" ? "باز کردن در تلگرام" : "Open in Telegram"}</span>
              </a>
            )}
            <label className="relative inline-flex items-center cursor-pointer flex-shrink-0" title={lang === "fa" ? "روشن / خاموش کردن ربات" : "Toggle Bot"}>
              <input
                type="checkbox"
                checked={botEnabled}
                onChange={(e) => setBotEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
            </label>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-200">
                {t.system.botTokenLabel}
              </label>
              <span className="text-[11px] text-slate-400">
                {lang === "fa" ? "ساخت در تلگرام با @BotFather" : "Create via @BotFather"}
              </span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ..."
                dir="ltr"
                className="flex-1 bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all"
              />
              <button
                type="button"
                onClick={handleTestAndConnect}
                disabled={testingBot || !botToken.trim()}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 disabled:opacity-40 transition-all flex-shrink-0 active:scale-95"
              >
                {testingBot ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-950" />
                ) : (
                  <Zap className="w-3.5 h-3.5 text-slate-950" />
                )}
                <span>{testingBot ? (lang === "fa" ? "درحال بررسی..." : "Checking...") : (lang === "fa" ? "تست و اتصال سریع" : "Test & Connect")}</span>
              </button>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-200">
                {t.system.botOwnerIdLabel}
              </label>
              <span className="text-[10px] text-cyan-400 font-medium">
                {lang === "fa" ? "ثبت خودکار با استارت اول" : "Auto-claims on /start"}
              </span>
            </div>
            <input
              type="text"
              value={ownerId}
              onChange={(e) => setOwnerId(e.target.value)}
              placeholder={lang === "fa" ? "مثال: 589412345 (یا خالی بگذارید)" : "e.g. 589412345 (or leave blank)"}
              dir="ltr"
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition-all"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {lang === "fa" ? "API ID (اختیاری)" : "API ID (Optional)"}
              </label>
              <input
                type="text"
                value={apiId}
                onChange={(e) => setApiId(e.target.value)}
                placeholder="2496"
                dir="ltr"
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {lang === "fa" ? "API HASH (اختیاری)" : "API HASH (Optional)"}
              </label>
              <input
                type="text"
                value={apiHash}
                onChange={(e) => setApiHash(e.target.value)}
                placeholder="my.telegram.org"
                dir="ltr"
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Button Layout & Style Arrangement (aiogram: 3-cols, 2-cols, 1-col) */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-medium text-slate-300">
                {lang === "fa" ? "چینش و استایل کلیدهای شیشه‌ای (پالت رنگی aiogram):" : "Inline Button Layout (aiogram style):"}
              </label>
              <div className="flex items-center gap-1.5 text-[10px]">
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">success</span>
                <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">primary</span>
                <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">danger</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "3-cols", title: "سه‌تایی (۳ ستونه)", desc: "۳ دکمه در هر سطر" },
                { id: "2-cols", title: "دوتایی (۲ ستونه)", desc: "۲ دکمه در هر سطر" },
                { id: "1-col", title: "تک‌ستونه (۱ تایی)", desc: "۱ دکمه در هر سطر" },
              ].map((layout) => {
                const isSelected = buttonLayout === layout.id;
                return (
                  <button
                    key={layout.id}
                    type="button"
                    onClick={() => setButtonLayout(layout.id as any)}
                    className={`py-2 px-2.5 rounded-xl border text-center transition-all ${
                      isSelected
                        ? "bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold shadow-md shadow-cyan-950/40"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <div className="text-xs">{layout.title}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{layout.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Feedback Alert */}
        {botFeedback && (
          <div
            className={`p-3.5 rounded-xl border text-xs flex items-center gap-2.5 shadow-sm transition-all ${
              isFeedbackError
                ? "bg-rose-950/80 border-rose-500/50 text-rose-300"
                : "bg-emerald-950/80 border-emerald-500/50 text-emerald-300"
            }`}
          >
            {isFeedbackError ? (
              <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            ) : (
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
            )}
            <span className="leading-relaxed">{botFeedback}</span>
          </div>
        )}

        {/* Telegram Inline Glass Buttons Preview (Interactive Simulator) */}
        <div className="bg-slate-950/80 border border-cyan-900/40 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-slate-200">
                {lang === "fa" ? "پیش‌نمایش کلیدهای شیشه‌ای تلگرام (Inline Buttons)" : "Telegram Inline Glass Buttons Live Preview"}
              </span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono">
              v6 Telegram UI Pro
            </span>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            {lang === "fa"
              ? "پس از لمس دکمه «تست و اتصال سریع»، کافیست وارد ربات خود شوید و /start را ارسال کنید. این کلیدهای شیشه‌ای زیبا و تعاملی نمایش داده می‌شوند و با لمس هر کدام، وضعیت سلف و تبچی فوراً تغییر می‌کند:"
              : "After connecting, open your bot and send /start. These interactive glass buttons will be displayed in real time:"}
          </p>

          {/* Dynamic grid based on selected layout (3-cols, 2-cols, 1-col) */}
          <div className="space-y-2 max-w-lg mx-auto pt-1 font-sans">
            {(() => {
              const gridColsClass =
                buttonLayout === "1-col"
                  ? "grid-cols-1"
                  : buttonLayout === "2-cols"
                  ? "grid-cols-2"
                  : "grid-cols-3";

              const previewButtons = [
                { title: "ساعت سلف: روشن 🟢", style: "bg-emerald-950/70 border-emerald-500/50 text-emerald-300", badge: "success" },
                { title: "تبچی: فعال 🟢", style: "bg-blue-950/70 border-blue-500/50 text-blue-300", badge: "primary" },
                { title: "منشی هوشمند 💬", style: "bg-rose-950/70 border-rose-500/50 text-rose-300", badge: "danger" },
                { title: "جوین اجباری 🔒", style: "bg-emerald-950/70 border-emerald-500/50 text-emerald-300", badge: "success" },
                { title: "ابزارها و ارز 📈", style: "bg-blue-950/70 border-blue-500/50 text-blue-300", badge: "primary" },
                { title: "استایل فونت ✨", style: "bg-rose-950/70 border-rose-500/50 text-rose-300", badge: "danger" },
                { title: "اشتراک اکانت‌ها 📅", style: "bg-emerald-950/70 border-emerald-500/50 text-emerald-300", badge: "success" },
                { title: "آمار سیستم ⚡", style: "bg-blue-950/70 border-blue-500/50 text-blue-300", badge: "primary" },
                { title: "لاگ‌های زنده 📜", style: "bg-rose-950/70 border-rose-500/50 text-rose-300", badge: "danger" },
              ];

              return (
                <div className={`grid ${gridColsClass} gap-1.5`}>
                  {previewButtons.map((btn, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center justify-between py-2 px-2.5 rounded-xl border text-xs font-bold transition-all shadow-sm ${btn.style}`}
                    >
                      <span className="truncate">{btn.title}</span>
                      <span className="text-[9px] opacity-75 font-mono">[{btn.badge}]</span>
                    </div>
                  ))}
                </div>
              );
            })()}

            <div className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-900/90 border border-cyan-800/40 text-cyan-400 text-xs font-bold hover:border-cyan-500 cursor-default transition-all">
              <span>🔄 بروزرسانی وضعیت پنل 🔁</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          {botStatus === "connected" ? (
            <button
              type="button"
              onClick={handleDisconnectBot}
              disabled={savingBot}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-medium transition-all"
            >
              <Power className="w-3.5 h-3.5" />
              <span>{lang === "fa" ? "قطع ارتباط ربات" : "Disconnect Bot"}</span>
            </button>
          ) : (
            <div className="text-[11px] text-slate-500">
              {lang === "fa" ? "ربات هم‌اکنون غیرفعال است" : "Bot is currently inactive"}
            </div>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSaveBotSettings}
              disabled={savingBot}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 disabled:opacity-50 transition-all active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>
                {savingBot
                  ? (lang === "fa" ? "درحال ذخیره..." : "Saving...")
                  : t.self.saveChanges}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Saved Messages Commands Guide & Remote Commands */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Saved Messages Command Cheat Sheet */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-800">
            <Bookmark className="w-4 h-4 text-amber-400" />
            <h4 className="font-bold text-slate-100 text-sm">
              {t.system.commandsGuide}
            </h4>
          </div>

          <p className="text-xs text-slate-400">
            {lang === "fa"
              ? "با ارسال هر یک از دستورات زیر در بخش «پیام‌های ذخیره شده» (Saved Messages) اکانت تلگرام، ربات به صورت آنی پاسخ خواهد داد:"
              : "Send these commands directly into your Telegram account's 'Saved Messages':"}
          </p>

          <div className="space-y-2 text-xs font-mono">
            {[
              { cmd: "/self", desc: lang === "fa" ? "مشاهده وضعیت کامل سلف و دکمه‌های کنترل" : "View self status & interactive menu" },
              { cmd: "/self time on", desc: lang === "fa" ? "روشن کردن ساعت روی پروفایل" : "Turn profile clock on" },
              { cmd: "/self time off", desc: lang === "fa" ? "خاموش کردن ساعت روی پروفایل" : "Turn profile clock off" },
              { cmd: "/tabchi", desc: lang === "fa" ? "مشاهده وضعیت ارسال و آمار پیام‌ها" : "View Tabchi broadcast status & metrics" },
              { cmd: "/tabchi start", desc: lang === "fa" ? "شروع فوری ارسال خودکار تبچی" : "Start Tabchi broadcast immediately" },
              { cmd: "/tabchi stop", desc: lang === "fa" ? "توقف فوری ارسال تبچی" : "Stop Tabchi broadcast" },
              { cmd: "=1250 * 18 - 450", desc: lang === "fa" ? "محاسبه خودکار ریاضی در هر چت" : "Instant math in any chat" },
              { cmd: "قیمت دلار / btc", desc: lang === "fa" ? "استعلام لحظه‌ای طلا، ارز و کریپتو" : "Live currency & crypto quote" },
            ].map((c, i) => (
              <div key={i} className="p-2 bg-slate-950 rounded-xl flex items-center justify-between gap-2">
                <span className="text-cyan-400 font-bold" dir="ltr">{c.cmd}</span>
                <span className="text-slate-400 text-[11px]">{c.desc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Global Sound Notification Settings Card */}
        <div className="glass-panel rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm">
                  {lang === "fa" ? "اعلان‌های صوتی هوشمند (Audio Chimes)" : "Smart Sound Notifications"}
                </h4>
                <p className="text-[11px] text-slate-400">
                  {lang === "fa"
                    ? "پخش آوای ملایم و دلنشین هنگام ثبت سفارش جدید یا اتمام ارسال تبچی"
                    : "Subtle, non-intrusive harmonic tones on new orders and broadcast completions"}
                </p>
              </div>
            </div>

            {onToggleSound && (
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={soundEnabled}
                  onChange={onToggleSound}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
              </label>
            )}
          </div>

          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">
                {lang === "fa" ? "حجم صدای اعلان‌ها (Volume):" : "Notification Volume:"}
              </span>
              <span className="text-cyan-400 font-mono font-bold">
                {Math.round(volume * 100)}%
              </span>
            </div>

            {onVolumeChange && (
              <input
                type="range"
                min="0.05"
                max="1"
                step="0.05"
                value={volume}
                disabled={!soundEnabled}
                onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400 disabled:opacity-40"
              />
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span className="text-[11px] text-slate-400">
                  {lang === "fa" ? "سفارش جدید فروشگاه و اتمام تبچی" : "New store order & broadcast done"}
                </span>
              </div>

              {onTestSound && (
                <button
                  type="button"
                  onClick={onTestSound}
                  disabled={!soundEnabled}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-40 shadow-sm"
                >
                  <BellRing className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{lang === "fa" ? "تست پخش آوا" : "Test Sound"}</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Security & License Details */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-800">
            <Lock className="w-4 h-4 text-emerald-400" />
            <h4 className="font-bold text-slate-100 text-sm">
              {lang === "fa" ? "امنیت و لایسنس دائمی (Permanent License)" : "Security & Permanent License"}
            </h4>
          </div>

          <div className="p-3.5 bg-slate-950 rounded-xl space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">{lang === "fa" ? "وضعیت لایسنس:" : "License Status:"}</span>
              <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                {t.system.licenseActive}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{lang === "fa" ? "نسخه پکیج:" : "Package Version:"}</span>
              <span className="text-slate-200 font-mono">Hacker Edition v6.0.0 Pro</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{lang === "fa" ? "رمز ورود اولیه سرور:" : "Initial Startup Password:"}</span>
              <span className="text-cyan-400 font-mono font-bold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20" dir="ltr">
                samkaren12
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{lang === "fa" ? "پروتکل اتصال:" : "Connection Protocol:"}</span>
              <span className="text-slate-200 font-mono">GramJS MTProto v2.0 Native</span>
            </div>
          </div>

          {onOpenOwnerPasswordModal && (
            <button
              type="button"
              onClick={onOpenOwnerPasswordModal}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Key className="w-4 h-4 text-amber-400" />
              <span>{lang === "fa" ? "تغییر نام‌کاربری و رمز عبور اختصاصی مالک" : "Change Owner Username & Password"}</span>
            </button>
          )}

          <p className="text-[11px] text-slate-400 leading-relaxed">
            {lang === "fa"
              ? "🔒 سشن‌های تلگرام و کلیدهای ارتباطی به صورت کاملاً ایزوله در سرور اختصاصی ذخیره شده و بدون ذخیره هیچ‌گونه دیتایی روی سرورهای متفرقه اجرا می‌شوند."
              : "🔒 Telegram sessions and authentication keys are stored in an isolated, encrypted local state directory without 3rd-party relays."}
          </p>
        </div>
      </div>

      {/* DEDICATED TERMINAL ASSISTANT CLI CARD (sudo selfandtabchi) */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/20 border border-emerald-500/30 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-md">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-100 text-base">
                  {lang === "fa" ? "دستیار خط فرمان ترمینال (Terminal CLI)" : "Terminal Assistant CLI"}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  sudo selfandtabchi
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {lang === "fa"
                  ? "کنترل سریع سرور از طریق SSH بدون نیاز به مرورگر (آپدیت، حذف، دامنه، SSL و ریستارت)"
                  : "Quick server control directly via SSH (Update, Uninstall, Domain, SSL & Restart)"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 border border-emerald-500/40 rounded-xl px-3.5 py-2">
            <span className="text-slate-400 text-xs font-mono select-none">$</span>
            <code className="text-emerald-400 font-mono font-bold text-xs">sudo selfandtabchi</code>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText("sudo selfandtabchi");
                setCopiedCmd(true);
                setTimeout(() => setCopiedCmd(false), 2000);
              }}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-emerald-300 transition-colors"
              title={lang === "fa" ? "کپی دستور" : "Copy command"}
            >
              {copiedCmd ? <Check className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
              <span className="w-5 h-5 rounded-md bg-emerald-500/20 flex items-center justify-center text-[11px] font-mono">3</span>
              <span>{lang === "fa" ? "بروزرسانی خودکار" : "Update Script"}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "fa"
                ? "دریافت آخرین پکیج‌ها، بیلد مجدد و اعمال تغییرات جدید با یک عدد"
                : "Pull latest updates, rebuild assets and reload daemon automatically"}
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
              <span className="w-5 h-5 rounded-md bg-cyan-500/20 flex items-center justify-center text-[11px] font-mono">4</span>
              <span>{lang === "fa" ? "تنظیم و چنج دامنه" : "Set & Change Domain"}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "fa"
                ? "اتصال دامنه دلخواه به آی‌پی سرور یا تغییر ساب‌دامین به سادگی"
                : "Link custom domains or subdomains to server IP seamlessly"}
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-purple-400 font-bold text-xs">
              <span className="w-5 h-5 rounded-md bg-purple-500/20 flex items-center justify-center text-[11px] font-mono">5</span>
              <span>{lang === "fa" ? "صدور SSL برای IP یا دامنه" : "Issue SSL (IP/Domain)"}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "fa"
                ? "گرفتن گواهی امنیتی Let's Encrypt یا OpenSSL SAN برای آی‌پی سرور"
                : "Instant SSL certificates with automatic renewal for domains and IPs"}
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
              <span className="w-5 h-5 rounded-md bg-amber-500/20 flex items-center justify-center text-[11px] font-mono">1</span>
              <span>{lang === "fa" ? "شروع و ریستارت سرویس" : "Start & Restart"}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "fa"
                ? "راه‌اندازی فوری پروسه و آزادسازی پورت‌ها در صورت اختلال سرور"
                : "Restart background processes and flush ports instantly"}
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-blue-400 font-bold text-xs">
              <span className="w-5 h-5 rounded-md bg-blue-500/20 flex items-center justify-center text-[11px] font-mono">7</span>
              <span>{lang === "fa" ? "مشاهده لاگ‌های زنده" : "Live PM2 Logs"}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "fa"
                ? "مشاهده زنده فعالیت اکانت‌های سلف، تبچی و سفارش‌های ربات"
                : "Watch real-time live logs of Telegram engine and requests"}
            </p>
          </div>

          <div className="bg-slate-950/80 border border-red-500/20 rounded-xl p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-red-400 font-bold text-xs">
              <span className="w-5 h-5 rounded-md bg-red-500/20 flex items-center justify-center text-[11px] font-mono">9</span>
              <span>{lang === "fa" ? "حذف کامل اسکریپت" : "Full Uninstall"}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "fa"
                ? "توقف همه سرویس‌ها، پاکسازی کامل فایل‌ها و حذف بدون ردپا از سرور"
                : "Safely kill processes, purge databases and wipe application cleanly"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-slate-400 bg-slate-950/50 p-2.5 rounded-lg border border-slate-800">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            {lang === "fa"
              ? "نکته: دستور sudo selfandtabchi در هنگام نصب اسکریپت به صورت سراسری در لینوکس ثبت شده و در هر مسیری قابل اجراست."
              : "Tip: sudo selfandtabchi is installed as a global binary and can be called from any directory in your Linux terminal."}
          </span>
        </div>
      </div>

      {/* DEDICATED AUTO-BACKUP & ENCRYPTED VAULT MANAGER */}
      <AutoBackupManager lang={lang} />

      {/* DEDICATED REPOSITORY UPDATE MANAGER & CHANGELOG */}
      <UpdateManager lang={lang} />

      {/* COMPREHENSIVE SSL BACKGROUND SERVICE MONITOR & AUTO-RENEWAL DAEMON */}
      <SslBackgroundServiceManager lang={lang} onOpenHelp={onOpenHelp} />
    </div>
  );
};
