import React, { useState, useMemo } from "react";
import {
  Users,
  Copy,
  Check,
  Power,
  RefreshCw,
  Clock,
  MessageSquare,
  Radio,
  ShieldCheck,
  AlertTriangle,
  Plus,
  Calendar,
  Infinity as InfinityIcon,
  Sparkles,
  Bot,
  KeyRound,
  Lightbulb,
  FilterX,
} from "lucide-react";
import { Language, translations } from "../utils/i18n";
import { TelegramAccount } from "../types";
import { ExtendSubscriptionModal } from "./ExtendSubscriptionModal";
import { AccountBotModal } from "./AccountBotModal";
import { CustomerCredentialsModal } from "./CustomerCredentialsModal";
import { AccountStatusBadge } from "./AccountStatusBadge";
import {
  AccountsFilterToolbar,
  AccountFiltersState,
  defaultAccountFilters,
} from "./AccountsFilterToolbar";

interface AccountsListProps {
  accounts: TelegramAccount[];
  selectedPhone: string | null;
  onSelectAccount: (phone: string) => void;
  onOpenConnectModal: () => void;
  onRefresh: () => void;
  lang: Language;
  onOpenHelp?: (section?: any) => void;
}

export const AccountsList: React.FC<AccountsListProps> = ({
  accounts,
  selectedPhone,
  onSelectAccount,
  onOpenConnectModal,
  onRefresh,
  lang,
  onOpenHelp,
}) => {
  const t = translations[lang];
  const [copiedPhone, setCopiedPhone] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [subscriptionTargetAccount, setSubscriptionTargetAccount] = useState<TelegramAccount | null>(null);
  const [botTargetAccount, setBotTargetAccount] = useState<TelegramAccount | null>(null);
  const [credentialsTargetAccount, setCredentialsTargetAccount] = useState<TelegramAccount | null>(null);
  const [filters, setFilters] = useState<AccountFiltersState>(defaultAccountFilters);

  const filteredAccounts = useMemo(() => {
    return accounts
      .filter((acc) => {
        // 1. Search Query
        if (filters.searchQuery.trim()) {
          const q = filters.searchQuery.trim().toLowerCase();
          const phoneMatch = acc.phone.toLowerCase().includes(q);
          const nameMatch = `${acc.firstName || ""} ${acc.lastName || ""}`.toLowerCase().includes(q);
          const userMatch = (acc.username || "").toLowerCase().includes(q);
          if (!phoneMatch && !nameMatch && !userMatch) return false;
        }

        // 2. Online Status
        if (filters.onlineStatus === "online" && !acc.isOnline) return false;
        if (filters.onlineStatus === "offline" && acc.isOnline) return false;

        // 3. Subscription Status
        const sub = acc.subscription;
        const isUnlimited = !sub || sub.is_unlimited;
        const now = Date.now();
        const expiresAt = sub?.expires_at ? new Date(sub.expires_at).getTime() : null;
        const isExpired = !isUnlimited && expiresAt !== null && expiresAt <= now;
        const isExpiringSoon =
          !isUnlimited &&
          !isExpired &&
          expiresAt !== null &&
          expiresAt - now <= 3 * 24 * 60 * 60 * 1000;
        const isValid = isUnlimited || (!isExpired && expiresAt !== null && expiresAt > now);

        if (filters.subscriptionStatus === "unlimited" && !isUnlimited) return false;
        if (filters.subscriptionStatus === "active" && !isValid) return false;
        if (filters.subscriptionStatus === "expiring_soon" && !isExpiringSoon) return false;
        if (filters.subscriptionStatus === "expired" && !isExpired) return false;

        // 4. Broadcast Load
        const isBroadcasting =
          acc.features?.tabchi?.status === "broadcasting" ||
          acc.features?.broadcast?.status === "broadcasting";
        const totalBroadcastSent =
          (acc.features?.tabchi?.total_sent || 0) + (acc.features?.broadcast?.total_sent || 0);

        if (filters.broadcastLoad === "broadcasting" && !isBroadcasting) return false;
        if (filters.broadcastLoad === "high" && totalBroadcastSent < 500) return false;
        if (
          filters.broadcastLoad === "medium" &&
          (totalBroadcastSent < 100 || totalBroadcastSent >= 500)
        )
          return false;
        if (filters.broadcastLoad === "low_idle" && totalBroadcastSent >= 100) return false;

        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === "broadcast_sent") {
          const sentA = (a.features?.tabchi?.total_sent || 0) + (a.features?.broadcast?.total_sent || 0);
          const sentB = (b.features?.tabchi?.total_sent || 0) + (b.features?.broadcast?.total_sent || 0);
          return sentB - sentA;
        }
        if (filters.sortBy === "phone") {
          return a.phone.localeCompare(b.phone);
        }
        if (filters.sortBy === "expiry") {
          const expA = a.subscription?.is_unlimited
            ? Infinity
            : a.subscription?.expires_at
            ? new Date(a.subscription.expires_at).getTime()
            : 0;
          const expB = b.subscription?.is_unlimited
            ? Infinity
            : b.subscription?.expires_at
            ? new Date(b.subscription.expires_at).getTime()
            : 0;
          return expA - expB;
        }
        return 0;
      });
  }, [accounts, filters]);

  const handleCopySession = (phone: string, sessionString: string) => {
    navigator.clipboard.writeText(sessionString);
    setCopiedPhone(phone);
    setTimeout(() => setCopiedPhone(null), 2000);
  };

  const handleDisconnect = async (phone: string) => {
    if (!confirm(t.accounts.disconnectConfirm)) return;

    setActionLoading(phone);
    try {
      const res = await fetch(`/api/accounts/${encodeURIComponent(phone)}/disconnect`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Failed to disconnect");
      onRefresh();
    } catch (err) {
      alert("Error disconnecting account");
    } finally {
      setActionLoading(null);
    }
  };

  const handleReconnect = async (phone: string) => {
    setActionLoading(phone);
    try {
      const res = await fetch(`/api/accounts/${encodeURIComponent(phone)}/reconnect`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Failed to reconnect");
      onRefresh();
    } catch (err) {
      alert("Error reconnecting account");
    } finally {
      setActionLoading(null);
    }
  };

  const renderSubscriptionStatus = (acc: TelegramAccount) => {
    const sub = acc.subscription;
    if (!sub || sub.is_unlimited) {
      return (
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
          <InfinityIcon className="w-3.5 h-3.5" />
          <span>{lang === "fa" ? "اشتراک نامحدود (دائمی)" : "Unlimited Subscription"}</span>
        </div>
      );
    }

    if (sub.expires_at) {
      const expiry = new Date(sub.expires_at);
      const diffMs = expiry.getTime() - Date.now();

      if (diffMs <= 0) {
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-400 text-xs font-bold animate-pulse">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{lang === "fa" ? "⛔ اشتراک منقضی شده (نیازمند تمدید)" : "⛔ Subscription Expired"}</span>
          </div>
        );
      }

      const daysLeft = Math.floor(diffMs / (24 * 60 * 60 * 1000));
      const hoursLeft = Math.floor((diffMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));

      return (
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-medium">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span>
            {lang === "fa"
              ? `⏳ باقی‌مانده: ${daysLeft} روز و ${hoursLeft} ساعت`
              : `⏳ Left: ${daysLeft}d ${hoursLeft}h`}
          </span>
        </div>
      );
    }

    return null;
  };

  if (accounts.length === 0) {
    return (
      <div
        className="p-10 text-center bg-slate-900 border border-slate-800 rounded-2xl max-w-lg mx-auto shadow-2xl"
        dir={lang === "fa" ? "rtl" : "ltr"}
      >
        <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mx-auto mb-4 shadow-lg shadow-cyan-500/10">
          <Users className="w-7 h-7" />
        </div>
        <h3 className="text-base font-bold text-slate-100">
          {t.noAccounts}
        </h3>
        <p className="text-xs text-slate-400 mt-1.5 mb-6 leading-relaxed">
          {t.noAccountsDesc}
        </p>
        <button
          onClick={onOpenConnectModal}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all transform active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>{t.connectFirstAccount}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4" dir={lang === "fa" ? "rtl" : "ltr"}>
      <div className="flex items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-100 text-sm sm:text-base flex items-center gap-2">
            <span>{t.accounts.title}</span>
            <span className="px-2 py-0.5 rounded-full text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-mono">
              {accounts.length}
            </span>
          </h3>
          <p className="text-xs text-slate-400">
            {lang === "fa"
              ? "مدیریت جداگانه هر شماره تلفن، تعیین روزشمار، تمدید اشتراک و بررسی وضعیت آنلاین بودن"
              : "Manage each phone number independently, configure subscription days, extend access, and monitor status"}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {onOpenHelp && (
            <button
              type="button"
              onClick={() => onOpenHelp("accounts")}
              className="px-3 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.2)] transition-all active:scale-95 cursor-pointer whitespace-nowrap"
              title="آموزش تصویری اتصال اکانت"
            >
              <Lightbulb className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>راهنمای اتصال 💡</span>
            </button>
          )}
          <button
            onClick={onOpenConnectModal}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.35)] transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>{lang === "fa" ? "افزودن شماره جدید" : "Add Account"}</span>
          </button>
          <button
            onClick={onRefresh}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all text-xs flex items-center gap-1.5"
            title="Refresh"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{lang === "fa" ? "بروزرسانی" : "Refresh"}</span>
          </button>
        </div>
      </div>

      {/* Advanced Filtering Toolbar */}
      <AccountsFilterToolbar
        filters={filters}
        onChangeFilters={setFilters}
        onResetFilters={() => setFilters(defaultAccountFilters)}
        totalAccountsCount={accounts.length}
        filteredAccountsCount={filteredAccounts.length}
        lang={lang}
      />

      {/* Accounts Grid */}
      {filteredAccounts.length === 0 ? (
        <div className="glass-panel rounded-3xl p-10 text-center border border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 mx-auto">
            <FilterX className="w-6 h-6 text-slate-500" />
          </div>
          <h4 className="text-sm font-bold text-white">
            {lang === "fa"
              ? "هیچ اکانتی با فیلترهای انتخابی مطابقت ندارد"
              : "No accounts match the selected filters"}
          </h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            {lang === "fa"
              ? "می‌توانید فیلترهای وضعیت اشتراک، اتصال آنلاین یا بار ترافیک برودکست را تغییر دهید یا دکمه زیر را برای نمایش همه اکانت‌ها بزنید."
              : "Try adjusting your subscription, online status, or broadcast load filters, or click below to reset all filters."}
          </p>
          <button
            type="button"
            onClick={() => setFilters(defaultAccountFilters)}
            className="px-4 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 text-xs font-bold transition-all cursor-pointer active:scale-95"
          >
            {lang === "fa" ? "پاکسازی فیلترها و نمایش همه اکانت‌ها" : "Reset Filters and Show All"}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAccounts.map((acc) => {
          const isSelected = acc.phone === selectedPhone;
          const isExpired =
            acc.subscription &&
            !acc.subscription.is_unlimited &&
            acc.subscription.expires_at &&
            new Date(acc.subscription.expires_at).getTime() <= Date.now();

          return (
            <div
              key={acc.phone}
              className={`glass-card-interactive rounded-3xl p-5 sm:p-6 transition-all relative ${
                isSelected
                  ? "border-cyan-500/80 shadow-2xl shadow-cyan-500/15 ring-1 ring-cyan-500/40 bg-slate-900/90"
                  : isExpired
                  ? "border-rose-500/50 bg-rose-950/20 shadow-lg shadow-rose-950/30"
                  : "hover:border-cyan-500/40"
              }`}
            >
              {/* Top info */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center text-white font-bold text-lg shadow-md flex-shrink-0">
                    {acc.firstName ? acc.firstName[0].toUpperCase() : "U"}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-slate-100 text-sm truncate">
                      {acc.firstName || "Telegram User"} {acc.lastName}
                    </h4>
                    <p className="text-xs text-slate-400 font-mono truncate" dir="ltr">
                      {acc.phone} {acc.username ? `@${acc.username}` : ""}
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono truncate" dir="ltr">
                      ID: {acc.userId}
                    </p>
                  </div>
                </div>

                {/* Status Badge with Framer Motion Transition Pulse & Select button */}
                <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 flex-shrink-0">
                  <AccountStatusBadge
                    isOnline={acc.isOnline}
                    phone={acc.phone}
                    lang={lang}
                  />

                  {/* Select button */}
                  <button
                    onClick={() => onSelectAccount(acc.phone)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex-shrink-0 cursor-pointer ${
                      isSelected
                        ? "bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
                        : "bg-slate-800 text-slate-300 hover:text-white"
                    }`}
                  >
                    {isSelected ? (lang === "fa" ? "حساب فعال" : "Active") : (lang === "fa" ? "انتخاب" : "Select")}
                  </button>
                </div>
              </div>

              {/* Subscription Status Bar */}
              <div className="my-3 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between gap-2 flex-wrap">
                {renderSubscriptionStatus(acc)}

                <button
                  onClick={() => setSubscriptionTargetAccount(acc)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all shadow-sm"
                  title="Extend or change subscription"
                >
                  <Calendar className="w-3.5 h-3.5 text-purple-400" />
                  <span>{lang === "fa" ? "تمدید اشتراک 📅" : "Extend"}</span>
                </button>
              </div>

              {/* Aiogram-Style Color-Coded Control Buttons */}
              <div className="grid grid-cols-2 gap-2 my-3">
                <button
                  onClick={() => setBotTargetAccount(acc)}
                  className={`flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-bold border transition-all shadow-sm transform active:scale-95 ${
                    acc.bot?.enabled && acc.bot?.bot_token
                      ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25 shadow-emerald-500/10"
                      : "bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white"
                  }`}
                  title={lang === "fa" ? "ربات تلگرام اختصاصی این شماره" : "Dedicated Telegram Bot"}
                >
                  <Bot className={`w-4 h-4 ${acc.bot?.enabled ? "text-emerald-400 animate-pulse" : "text-slate-400"}`} />
                  <span className="truncate">
                    {acc.bot?.enabled && acc.bot?.bot_token
                      ? (lang === "fa" ? "🟢 ربات تلگرام شماره" : "🟢 Account Bot")
                      : (lang === "fa" ? "🤖 تنظیم ربات شماره" : "🤖 Setup Bot")}
                  </span>
                </button>

                <button
                  onClick={() => setCredentialsTargetAccount(acc)}
                  className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-bold bg-amber-500/15 border border-amber-500/40 text-amber-300 hover:bg-amber-500/25 transition-all shadow-sm shadow-amber-500/10 transform active:scale-95"
                  title={lang === "fa" ? "مشخصات ورود مشتری به پنل وب" : "Customer Panel Credentials"}
                >
                  <KeyRound className="w-4 h-4 text-amber-400" />
                  <span className="truncate">
                    {lang === "fa" ? "🔑 ورود مشتری به پنل" : "🔑 Customer Login"}
                  </span>
                </button>
              </div>

              {/* Status Feature Badges */}
              <div className="flex flex-wrap gap-2 mb-4 pt-2 border-t border-slate-800/80">
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium ${
                    acc.features?.self_time?.active
                      ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                      : "bg-slate-950 text-slate-500 border border-slate-800"
                  }`}
                >
                  <Clock className="w-3 h-3" />
                  <span>
                    {lang === "fa" ? "ساعت پروفایل" : "Self-Time"}:{" "}
                    {acc.features?.self_time?.active ? (lang === "fa" ? "فعال" : "ON") : (lang === "fa" ? "خاموش" : "OFF")}
                  </span>
                </span>

                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium ${
                    acc.features?.auto_reply?.active
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                      : "bg-slate-950 text-slate-500 border border-slate-800"
                  }`}
                >
                  <MessageSquare className="w-3 h-3" />
                  <span>
                    {lang === "fa" ? "منشی هوشمند" : "Auto-Reply"}:{" "}
                    {acc.features?.auto_reply?.active ? (lang === "fa" ? "فعال" : "ON") : (lang === "fa" ? "خاموش" : "OFF")}
                  </span>
                </span>

                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium ${
                    acc.features?.tabchi?.status === "broadcasting"
                      ? "bg-purple-500/10 text-purple-400 border border-purple-500/20 animate-pulse"
                      : "bg-slate-950 text-slate-500 border border-slate-800"
                  }`}
                >
                  <Radio className="w-3 h-3" />
                  <span>
                    {lang === "fa" ? "تبچی" : "Tabchi"}:{" "}
                    {acc.features?.tabchi?.total_sent || 0} {lang === "fa" ? "ارسال" : "sent"}
                  </span>
                </span>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => handleCopySession(acc.phone, acc.sessionString)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white text-xs transition-colors border border-slate-800 font-mono"
                  title="Copy Telethon / GramJS StringSession"
                >
                  {copiedPhone === acc.phone ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-cyan-400" />
                  )}
                  <span>
                    {copiedPhone === acc.phone ? (lang === "fa" ? "کپی شد" : "Copied") : t.accounts.copySession}
                  </span>
                </button>

                <div className="flex items-center gap-2">
                  {!acc.isOnline && (
                    <button
                      onClick={() => handleReconnect(acc.phone)}
                      disabled={actionLoading === acc.phone}
                      className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-xs border border-emerald-500/30 transition-colors"
                      title={t.accounts.reconnect}
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => handleDisconnect(acc.phone)}
                    disabled={actionLoading === acc.phone}
                    className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs border border-rose-500/30 transition-colors"
                    title={t.accounts.disconnect}
                  >
                    <Power className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    )}

      {/* Extend Subscription Modal */}
      <ExtendSubscriptionModal
        isOpen={Boolean(subscriptionTargetAccount)}
        onClose={() => setSubscriptionTargetAccount(null)}
        account={subscriptionTargetAccount}
        onSuccess={onRefresh}
        lang={lang}
      />

      {/* Account Dedicated Bot Modal */}
      <AccountBotModal
        isOpen={Boolean(botTargetAccount)}
        onClose={() => setBotTargetAccount(null)}
        account={botTargetAccount}
        onSuccess={onRefresh}
        lang={lang}
      />

      {/* Customer Web Panel Credentials Modal */}
      <CustomerCredentialsModal
        isOpen={Boolean(credentialsTargetAccount)}
        onClose={() => setCredentialsTargetAccount(null)}
        account={credentialsTargetAccount}
        onSuccess={onRefresh}
        lang={lang}
      />
    </div>
  );
};

